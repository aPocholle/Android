package com.example.td2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    SeekBar sb;
    TextView nm;
    int value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sb = (SeekBar)findViewById(R.id.seekBar);
        nm = (TextView)findViewById(R.id.Number);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekbar, int progress, boolean fromUser){
                nm.setText(String.valueOf(progress));
                value = progress;
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar){

            }
            @Override
            public void onStartTrackingTouch(SeekBar seekbar){

            }
        });

        Button buttonClick = (Button)findViewById(R.id.ENVOYER);
        buttonClick.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent disp = new Intent(MainActivity.this, DisplayActivity.class);
                EditText champtxt = (EditText)findViewById(R.id.CHMPTXT);
                String name = champtxt.getText().toString();
                disp.putExtra("name",name);
                CalendarView cal = findViewById(R.id.calendarView);
                long timestamp = cal.getDate();
                Date date = new Date(timestamp);
                disp.putExtra("date",date);
                disp.putExtra("valeur",value);
                startActivity(disp);
            }
        });

    }


}